% UQ_SENDFEEDBACK Open a dialog to send feedback to the Dev Team
%    UQ_SENDFEEDBACK opens a web form that can be used to send direct
%    feedback about UQLab to the developers, including bug reports,
%    enhancement and new feature requests
%
%